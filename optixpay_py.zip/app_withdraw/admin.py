from django.contrib import admin

from app_withdraw.models.withdraw import Withdraw

# Register your models here.


admin.site.register(Withdraw)
