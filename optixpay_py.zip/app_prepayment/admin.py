from django.contrib import admin

from app_prepayment.models.prepayment import Prepayment

# Register your models here.
admin.site.register(Prepayment)
